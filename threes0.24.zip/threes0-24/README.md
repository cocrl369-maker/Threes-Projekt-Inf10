# Threes0.24

A Pen created on CodePen.

Original URL: [https://codepen.io/ickxdrsp-the-styleful/pen/RNKRaOW](https://codepen.io/ickxdrsp-the-styleful/pen/RNKRaOW).


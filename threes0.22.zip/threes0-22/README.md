# Threes0.22

A Pen created on CodePen.

Original URL: [https://codepen.io/ickxdrsp-the-styleful/pen/PwWNeNx](https://codepen.io/ickxdrsp-the-styleful/pen/PwWNeNx).


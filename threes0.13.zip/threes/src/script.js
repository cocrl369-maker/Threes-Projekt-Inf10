class Tile{ //Klasse Tile, damit man seperate, verschiebbare Kärtchen hat
  constructor(value=0){
    this.value = value
  }
  
  getColor() {
    const colors = {
      0: '#F8F8FF',
      1: '#00FFFF',
      2: '#FF6347',
      3: '#C0C0C0',
      6: '#C0C0C0',
      12: '#C0C0C0',
      24: '#C0C0C0',
      48: '#C0C0C0',
      96: '#C0C0C0',
      192: '#C0C0C0',
      384: '#C0C0C0',
      768: '#C0C0C0'
      // ... hier die restlichen Farben
    };
    return colors[this.value] || '#cdc1b4';
  }

  getHTML() {
    const bgColor = this.getColor();
    const textColor = this.value > 4 ? 'white' : '#776e65';
    const displayValue = this.value === 0 ? '' : this.value;
    
    return `<td style="background-color: ${bgColor}; color: ${textColor};">
              ${displayValue}
            </td>`;
  }
}
class Spielfeld {
  constructor() {
    this.grid = this.createEmptyGrid(); // grid als Variable in der Klasse Spielfeld
  }

  createEmptyGrid() {
    let grid = [];
    for (let r = 0; r < 4; r++) {
      let row = [];
      for (let c = 0; c < 4; c++) {
        row.push(new Tile(0)); // Überall "leere" Tile-Objekte
      }
      grid.push(row);
    }
    return grid;
  }
setValue(row, col, value) {
  if (this.isValidPosition(row, col)) {
      this.grid[row][col].value = value;
  }
}
   getValue(row, col) {
    return this.isValidPosition(row, col) ? this.grid[row][col] : null;
  }

  isValidPosition(row, col) { // Wichtig für Merge-Algorithmus->"Spieldeldrand" (existiert die Koordinate)
    return row >= 0 && row < 4 && col >= 0 && col < 4;
  }
  
  displayInElement(elementId) { // HTML-Tabelle: Die Farben von Hintergrund (bgColor) und Text (textColor) passen sich dynamisch dem Wert der Kachel an.
    const container = document.getElementById(elementId);
    if (!container) return;
    
    let html = '<table>';
    
    for (let r = 0; r < 4; r++) {
      html += '<tr>';
      for (let c = 0; c < 4; c++) {
        html += this.grid[r][c].getHTML(); // Tile rendert sich selbst
      }
      html += '</tr>';
    }
    html += '</table>';
    container.innerHTML = html;
  } 
  print() {
    console.log('┌────┬────┬────┬────┐');
    for (let r = 0; r < 4; r++) {
      let rowStr = '│';
      for (let c = 0; c < 4; c++) {
        let val = this.grid[r][c].value;
        rowStr += ` ${val.toString().padStart(2, ' ')} │`;
      }
      console.log(rowStr);
      if (r < 3) console.log('├────┼────┼────┼────┤');
    }
    console.log('└────┴────┴────┴────┘');
  }
  
  // Für Debugging: Text-Ausgabe im HTML
  debugToHTML(elementId) {
    const container = document.getElementById(elementId);
    if (!container) return;
    
    let text = 'Aktuelles Spielfeld:\n';
    for (let r = 0; r < 4; r++) {
      text += '[';
      for (let c = 0; c < 4; c++) {
        text += ' ' + this.grid[r][c].value.toString().padStart(3, ' '); // .value wegen Objekt durch "Tile" anstatt Zahlenwert
      }
      text += ' ]\n';
    }
    
    container.innerHTML = '<pre>' + text + '</pre>';
  }
}


// Spielfeld global machen für Button-Zugriff
let spielfeld;

function startGame() {
  spielfeld = new Spielfeld();
  spielfeld.setValue(0, 0, 1)
  spielfeld.setValue(1, 1, 2)
  spielfeld.debugToHTML('debug-output');
  spielfeld.print(); // In Konsole
  spielfeld.displayInElement('board-display');
  
}
function pressLeft() {
  for (let r = 0; r < 4; r++) {
      for (let c = 0; c < 4; c++) {
        if (c >= 1 && spielfeld.grid[r][c].value > 0) {//wichtig! .value (Eigenschaft des Tiles) 
           spielfeld.setValue(r, c - 1, spielfeld.grid[r][c].value);
           spielfeld.setValue(r, c, spielfeld.grid[r][c].value = 0)
        }
      }
    
  }
  spielfeld.displayInElement('board-display');
    spielfeld.debugToHTML('debug-output');

}


  

// Beim Laden starten
window.onload = startGame;
# Threes0.23

A Pen created on CodePen.

Original URL: [https://codepen.io/ickxdrsp-the-styleful/pen/xbgVjLL](https://codepen.io/ickxdrsp-the-styleful/pen/xbgVjLL).


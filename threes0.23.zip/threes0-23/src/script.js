class Tile {
  //Klasse Tile, damit man seperate, verschiebbare Kärtchen hat
  constructor(value = 0) {
    this.value = value;
  }

  getColor() {
    const colors = {
      0: "#F8F8FF",
      1: "#00FFFF",
      2: "#FF6347",
      3: "#C0C0C0",
      6: "#C0C0C0",
      12: "#C0C0C0",
      24: "#C0C0C0",
      48: "#C0C0C0",
      96: "#C0C0C0",
      192: "#C0C0C0",
      384: "#C0C0C0",
      768: "#C0C0C0"
      // hier die restlichen Farben
    };
    return colors[this.value] || "#cdc1b4"; // wenn keiner der Werte -> beige
  }

  getHTML() {
    //Erzeugt das HTML-Element für dieses einzelne Kärtchen. Wird in der Schleife vom Spielfeld aufgerufen.
    const bgColor = this.getColor(); //Farbe festlegen
    const textColor = this.value > 4 ? "white" : "black"; //Farbe für den Zahlenwert
    const displayValue = this.value === 0 ? "" : this.value; //keine Farbe für Wert = 0

    return `<td style="background-color: ${bgColor}; color: ${textColor};"> 
              ${displayValue}
            </td>`; // Rückgabe (HTML-String)
  }
}
class Spielfeld {
  constructor() {
    this.grid = this.createEmptyGrid(); // grid als Variable in der Klasse Spielfeld
    this.nextTile = new Tile(getRandomIntInclusive(1, 3));
  }

  createEmptyGrid() {
    let grid = [];
    for (let r = 0; r < 4; r++) {
      //äußere Schleife
      let row = [];
      for (let c = 0; c < 4; c++) {
        //innere Schleife
        row.push(new Tile(0)); // Überall "leere" Tile-Objekte
      }
      grid.push(row);
    }
    return grid;
  }

  setValue(row, col, value) {
    // Wert festlegen für Koordinate
    if (this.isValidPosition(row, col)) {
      this.grid[row][col].value = value;
    }
  }

  getValue(row, col) {
    return this.isValidPosition(row, col) ? this.grid[row][col] : null;
  }

  isValidPosition(row, col) {
    // Wichtig für Merge-Algorithmus->"Spieldeldrand" (existiert die Koordinate)
    return row >= 0 && row < 4 && col >= 0 && col < 4;
  }

  //setPosition(row, col, val){
  //if (this.isValidPosition(row, col)) {
  //this.grid[row][col].position = position;
  // }
  // }

  getEmptyCells() {
    let empty = [];
    for (let r = 0; r < 4; r++) {
      for (let c = 0; c < 4; c++) {
        if (this.grid[r][c].value === 0) {
          //wichtig! .value (Eigenschaft des Tiles)
          empty.push({ row: r, col: c });
        }
      }
    }
    return empty;
  }

  getNextTile() {
    const old = this.nextTile;
    this.nextTile = new Tile(getRandomIntInclusive(1, 3));
    return old;
  }

  addRandomTile() {
    const emptyCells = this.getEmptyCells();
    if (emptyCells.length > 0) {
      const randomIndex = Math.floor(Math.random() * emptyCells.length);
      const { row, col } = emptyCells[randomIndex];
      const value = getRandomIntInclusive(1, 3);
      this.setValue(row, col, value);
      return { row, col, value };
    }
    return null;
  }
  addRandomTileAt(emptyCells) {
    if (emptyCells.length > 0) {
      const randomIndex = getRandomIntInclusive(0, emptyCells.length - 1);
      const idx = emptyCells[randomIndex];
      const tile = this.getNextTile();
      return [idx, tile.value];
    }
    return null;
  }

  displayNext() {
    const container = document.getElementById("next-tile");
    if (!container) return;

    let html = "<table>";
    html += "<tr>";
    html += this.nextTile.getHTML(); // Tile rendert sich selbst
    html += "</tr>";
    html += "</table>";
    container.innerHTML = html;
  }

  displayInElement(elementId) {
    // HTML-Tabelle: Die Farben von Hintergrund (bgColor) und Text (textColor) passen sich dynamisch dem Wert der Kachel an.
    const container = document.getElementById(elementId);
    if (!container) return;

    let html = "<table>";

    for (let r = 0; r < 4; r++) {
      html += "<tr>";
      for (let c = 0; c < 4; c++) {
        html += this.grid[r][c].getHTML(); // Tile rendert sich selbst
      }
      html += "</tr>";
    }
    html += "</table>";
    container.innerHTML = html;
  }

  print() {
    console.log("┌────┬────┬────┬────┐");
    for (let r = 0; r < 4; r++) {
      let rowStr = "│";
      for (let c = 0; c < 4; c++) {
        let val = this.grid[r][c].value;
        rowStr += ` ${val.toString().padStart(2, " ")} │`;
      }
      console.log(rowStr);
      if (r < 3) console.log("├────┼────┼────┼────┤");
    }
    console.log("└────┴────┴────┴────┘");
  }

  // Für Debugging: Text-Ausgabe im HTML
  debugToHTML(elementId) {
    const container = document.getElementById(elementId);
    if (!container) return;

    let text = "Aktuelles Spielfeld:\n";
    for (let r = 0; r < 4; r++) {
      text += "[";
      for (let c = 0; c < 4; c++) {
        text += " " + this.grid[r][c].value.toString().padStart(3, " "); // .value wegen Objekt durch "Tile" anstatt Zahlenwert
      }
      text += " ]\n";
    }
    const res = this.isfinished();

    if (res) {
      text += "\n";
      text += "FINISHED";

      const finalScore = this.score();
      const overlayScore = document.getElementById("finalScore");
      if (overlayScore) {
        overlayScore.innerHTML = "Punktestand: " + finalScore;
      }
      const overlayElement = document.getElementById("game-over-overlay");
      if (overlayElement) {
        overlayElement.style.display = "flex";
      }
    }
    container.innerHTML = "<pre>" + text + "</pre>";
  }

  test(left, right) {
    //updateLeftTile
    if (left.value == 0 && right.value > 0) {
      left.value = right.value;
      return true;
    } else if (
      (left.value == 1 && right.value == 2) ||
      (left.value == 2 && right.value == 1)
    ) {
      left.value = 3;
      return true;
    } else if (left.value > 2 && right.value > 2 && left.value == right.value) {
      left.value = left.value + right.value;
      return true;
    } else {
      return false;
    }
  }

  test2(left, right) {
    //updateLeftTile
    if (left.value == 0 && right.value > 0) {
      return true;
    } else if (
      (left.value == 1 && right.value == 2) ||
      (left.value == 2 && right.value == 1)
    ) {
      return true;
    } else if (left.value > 2 && right.value > 2 && left.value == right.value) {
      return true;
    } else {
      return false;
    }
  }

  updateRow(row) {
    let shifted = false;
    for (let c = 0; c < 3; c++) {
      if (shifted == true) {
        row[c].value = row[c + 1].value;
      } else {
        shifted = this.test(row[c], row[c + 1]);
        console.log(`shifted: ${shifted}`);
      }
    }
    if (shifted == true) {
      row[3].value = 0;
    }
    return shifted;
  }

  isRowShiftable(row) {
    let shiftable = false;
    for (let c = 0; c < 3; c++) {
      shiftable = this.test2(row[c], row[c + 1]);
      console.log(`shiftable: ${shiftable}`);
      if (shiftable) {
        return shiftable;
      }
    }
    return shiftable;
  }

  isfinished() {
    // check left case
    for (let r = 0; r < 4; r++) {
      let copy = [...spielfeld.grid[r]]; //Copie der Reihe
      const shiftable = spielfeld.isRowShiftable(copy);
      if (shiftable == true) {
        return false;
      }
    }
    // check right case
    for (let r = 0; r < 4; r++) {
      let copy = [...spielfeld.grid[r]].reverse(); //Copie der Reihe
      const shiftable = spielfeld.isRowShiftable(copy);
      if (shiftable == true) {
        return false;
      }
    }
    // check Up case
    const arrayColumn = (arr, n) => arr.map((x) => x[n]); // Internet: get column from a 2D array
    for (let c = 0; c < 4; c++) {
      let col = arrayColumn(spielfeld.grid, c);

      let copy = [...col]; //Copie der Spalte
      const shiftable = spielfeld.isRowShiftable(copy);
      if (shiftable == true) {
        return false;
      }
    }
    // check down case
    for (let c = 0; c < 4; c++) {
      let col = arrayColumn(spielfeld.grid, c);

      let copy = [...col].reverse(); //Copie der Spalte
      const shiftable = spielfeld.isRowShiftable(copy);
      if (shiftable == true) {
        return false;
      }
    }
    return true;
  }

  score() {
    let highscore = 0;
    for (let r = 0; r < 4; r++) {
      for (let c = 0; c < 4; c++) {
        if (this.grid[r][c].value > 2) {
          highscore += 3 ** (Math.log2(spielfeld.grid[r][c].value / 3) + 1);
          //const scoreElement = document.getElementById("score");
        }
      }
    }
    const scoreElement = document.getElementById("score");
    document.getElementById("score").innerHTML = "Score: " + highscore;
    return highscore;
  }
}

function getRandomIntInclusive(min, max) {
  const minCeiled = Math.ceil(min);
  const maxFloored = Math.floor(max);
  return Math.floor(Math.random() * (maxFloored - minCeiled + 1) + minCeiled); // The maximum is inclusive and the minimum is inclusive
}

// Spielfeld global machen für Button-Zugriff
let spielfeld;

function startGame() {
  const overlayElement = document.getElementById("game-over-overlay");

  if (overlayElement) {
    overlayElement.style.display = "none";
  }

  spielfeld = new Spielfeld();
  spielfeld.setValue(0, 0, 1);
  spielfeld.setValue(1, 1, 2);
  spielfeld.setValue(3, 3, 3);
  spielfeld.displayInElement("board-display");
  spielfeld.debugToHTML("debug-output");
  spielfeld.displayNext();
  spielfeld.score();
  console.clear();
  //spielfeld.print(); // In Konsole
}

function addRandomTile() {
  if (spielfeld) {
    const newTile = spielfeld.addRandomTile();
    if (newTile) {
      console.log(
        `Neues Kärtchen: ${newTile.value} bei (${newTile.row}, ${newTile.col})`
      );
    } else {
      console.log("Keine leeren Zellen mehr!");
    }
    spielfeld.displayInElement("board-display");
    spielfeld.debugToHTML("debug-output");
    spielfeld.score();
  }
}

function pressLeft() {
  let shiftedRows = [];
  for (let r = 0; r < 4; r++) {
    let copy = [...spielfeld.grid[r]]; //Copie der Reihe
    const shifted = spielfeld.updateRow(copy);
    if (shifted == true) {
      shiftedRows.push(r);
    }
  }
  console.log(`L Schiebbare Reihen: ${shiftedRows}`);
  if (shiftedRows.length > 0) {
    const [i, val] = spielfeld.addRandomTileAt(shiftedRows);
    // add at column 3, the tail of left move
    spielfeld.setValue(i, 3, val);
  }
  spielfeld.displayInElement("board-display");
  spielfeld.debugToHTML("debug-output");
  spielfeld.score();
  spielfeld.displayNext();
}

function pressRight() {
  let shiftedRows = [];
  for (let r = 0; r < 4; r++) {
    let copy = [...spielfeld.grid[r]].reverse(); //Copie der Reihe
    const shifted = spielfeld.updateRow(copy);
    if (shifted == true) {
      shiftedRows.push(r);
    }
  }
  console.log(`R Schiebbare Reihen: ${shiftedRows}`);
  if (shiftedRows.length > 0) {
    const [i, val] = spielfeld.addRandomTileAt(shiftedRows);
    // add at column 0, the tail of right move
    spielfeld.setValue(i, 0, val);
  }
  spielfeld.displayInElement("board-display");
  spielfeld.debugToHTML("debug-output");
  spielfeld.score();
  spielfeld.displayNext();
}

function pressUp() {
  let shiftedColoumns = [];
  const arrayColumn = (arr, n) => arr.map((x) => x[n]); // Internet: get column from a 2D array
  for (let c = 0; c < 4; c++) {
    let col = arrayColumn(spielfeld.grid, c);

    let copy = [...col]; //Copie der Spalte
    const shifted = spielfeld.updateRow(copy);
    if (shifted == true) {
      shiftedColoumns.push(c);
    }
  }
  console.log(`Up Schiebbare Spalten: ${shiftedColoumns}`);
  if (shiftedColoumns.length > 0) {
    const [i, val] = spielfeld.addRandomTileAt(shiftedColoumns);
    // add at column 0, the tail of right move
    spielfeld.setValue(3, i, val);
  }
  spielfeld.displayInElement("board-display");
  spielfeld.debugToHTML("debug-output");
  spielfeld.score();
  spielfeld.displayNext();
}

function pressDown() {
  let shiftedColoumns = [];
  const arrayColumn = (arr, n) => arr.map((x) => x[n]); // Internet: get column from a 2D array
  for (let c = 0; c < 4; c++) {
    let col = arrayColumn(spielfeld.grid, c);

    let copy = [...col].reverse(); //Copie der Spalte
    const shifted = spielfeld.updateRow(copy);
    if (shifted == true) {
      shiftedColoumns.push(c);
    }
  }
  console.log(`Down Schiebbare Spalten: ${shiftedColoumns}`);
  if (shiftedColoumns.length > 0) {
    const [i, val] = spielfeld.addRandomTileAt(shiftedColoumns);
    // add at column 0, the tail of right move
    spielfeld.setValue(0, i, val);
  }
  spielfeld.displayInElement("board-display");
  spielfeld.debugToHTML("debug-output");
  spielfeld.score();
  spielfeld.displayNext();
}

// Anschließend wird die Eingabe für den Nutzer optimiert, indem nun WASD und die Pfeiltasten zur Spielbedienung verwendet werden können. "event" ist der Übergabeparameter

document.addEventListener("keydown", function (event) {
  if (event.key == "w" || event.key == "ArrowUp") {
    pressUp();
  }

  if (event.key == "a" || event.key == "ArrowLeft") {
    pressLeft();
  }

  if (event.key == "s" || event.key == "ArrowDown") {
    pressDown();
  }

  if (event.key == "d" || event.key == "ArrowRight") {
    pressRight();
  }
});

// Beim Laden starten
window.onload = startGame;

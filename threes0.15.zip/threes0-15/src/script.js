class Tile{ //Klasse Tile, damit man seperate, verschiebbare Kärtchen hat
  constructor(value=0){
    this.value = value
  }
  
  getColor() {
    const colors = {
      0: '#F8F8FF',
      1: '#00FFFF',
      2: '#FF6347',
      3: '#C0C0C0',
      6: '#C0C0C0',
      12: '#C0C0C0',
      24: '#C0C0C0',
      48: '#C0C0C0',
      96: '#C0C0C0',
      192: '#C0C0C0',
      384: '#C0C0C0',
      768: '#C0C0C0'
      // hier die restlichen Farben
    };
    return colors[this.value] || '#cdc1b4'; // wenn keiner der Werte -> beige
  }

  getHTML() { //Erzeugt das HTML-Element für dieses einzelne Kärtchen. Wird in der Schleife vom Spielfeld aufgerufen.
    const bgColor = this.getColor(); //Farbe festlegen
    const textColor = this.value > 4 ? 'white' : '#776e65'; //Farbe für den Zahlenwert
    const displayValue = this.value === 0 ? '' : this.value; //keine Farbe für Wert = 0 
    
    return `<td style="background-color: ${bgColor}; color: ${textColor};"> 
              ${displayValue}
            </td>`; // Rückgabe (HTML-String)
  }
}
class Spielfeld {
  constructor() {
    this.grid = this.createEmptyGrid(); // grid als Variable in der Klasse Spielfeld
  }

  createEmptyGrid() {
    let grid = [];
    for (let r = 0; r < 4; r++) { //äußere Schleife
      let row = [];
      for (let c = 0; c < 4; c++) { //innere Schleife
        row.push(new Tile(0)); // Überall "leere" Tile-Objekte
      }
      grid.push(row);
    }
    return grid;
  }

  setValue(row, col, value) { // Wert festlegen für Koordinate
    if (this.isValidPosition(row, col)) {
      this.grid[row][col].value = value;
    }
  }

  getValue(row, col) { 
    return this.isValidPosition(row, col) ? this.grid[row][col] : null;
  }

  isValidPosition(row, col) { // Wichtig für Merge-Algorithmus->"Spieldeldrand" (existiert die Koordinate)
    return row >= 0 && row < 4 && col >= 0 && col < 4;
  }
  
  //setPosition(row, col, val){
    //if (this.isValidPosition(row, col)) {
      //this.grid[row][col].position = position;
  // }
 // }

  

  

  displayInElement(elementId) { // HTML-Tabelle: Die Farben von Hintergrund (bgColor) und Text (textColor) passen sich dynamisch dem Wert der Kachel an.
    const container = document.getElementById(elementId);
    if (!container) return;
    
    let html = '<table>';
    
    for (let r = 0; r < 4; r++) {
      html += '<tr>';
      for (let c = 0; c < 4; c++) {
        html += this.grid[r][c].getHTML(); // Tile rendert sich selbst
      }
      html += '</tr>';
    }
    html += '</table>';
    container.innerHTML = html;
  }
      

  print() {
    console.log('┌────┬────┬────┬────┐');
    for (let r = 0; r < 4; r++) {
      let rowStr = '│';
      for (let c = 0; c < 4; c++) {
        let val = this.grid[r][c].value;
        rowStr += ` ${val.toString().padStart(2, ' ')} │`;
      }
      console.log(rowStr);
      if (r < 3) console.log('├────┼────┼────┼────┤');
    }
    console.log('└────┴────┴────┴────┘');
  }
  
  // Für Debugging: Text-Ausgabe im HTML
  debugToHTML(elementId) {
    const container = document.getElementById(elementId);
    if (!container) return;
    
    let text = 'Aktuelles Spielfeld:\n';
    for (let r = 0; r < 4; r++) {
      text += '[';
      for (let c = 0; c < 4; c++) {
        text += ' ' + this.grid[r][c].value.toString().padStart(3, ' '); // .value wegen Objekt durch "Tile" anstatt Zahlenwert
      }
      text += ' ]\n';
    }
    
    container.innerHTML = '<pre>' + text + '</pre>';
  }
  
  test(left, right){
    if (left.value == 0 || right.value ==0){
      left.value = right.value + left.value;
      return true;
    }
    else if(left.value == 1 && right.value == 2 || left.value == 2 && right.value == 1){
      left.value = 3;
      return true;
    }
    else if (left.value > 2 && right.value > 2 && left.value == right.value){
      left.value = left.value + right.value;
      return true;
    }
    else {
      return false;
    }
  }
  
  
  updateRow(row) {
        let shifted = false;
        for (let c = 0; c < 3; c++) {
            if (shifted == true) {
                row[c].value = row[c + 1].value;
            }
            else {
                shifted = this.test(row[c], row[c + 1]);
                console.log(`shifted: ${shifted}`);
            }


        }
        if (shifted == true) {
            row[3].value = 0;
        }
    }
  
}


// Spielfeld global machen für Button-Zugriff
let spielfeld;

function startGame() {
  spielfeld = new Spielfeld();
  spielfeld.setValue(0, 0, 1);
  spielfeld.setValue(1, 1, 2);
  spielfeld.setValue(1, 3, 3);
  spielfeld.setValue(0, 3, 2);
  spielfeld.displayInElement('board-display');
  spielfeld.debugToHTML('debug-output');
  //spielfeld.print(); // In Konsole
}




function pressLeft() {
  for (let r = 0; r < 4; r++) {
    let arr = spielfeld.grid[r]
    spielfeld.updateRow(arr);
  
  }
  
  spielfeld.displayInElement('board-display');
    spielfeld.debugToHTML('debug-output');
}
// Beim Laden starten
window.onload = startGame;
# Threes0.15 

A Pen created on CodePen.

Original URL: [https://codepen.io/ickxdrsp-the-styleful/pen/MYjQdym](https://codepen.io/ickxdrsp-the-styleful/pen/MYjQdym).


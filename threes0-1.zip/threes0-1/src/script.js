class Spielfeld {
  constructor() {
    this.grid = this.createEmptyGrid(); // grid als Variable in der Klasse Spielfeld
  }

  createEmptyGrid() {
    return [
      [0, 0, 0, 0],
      [0, 0, 0, 0],
      [0, 0, 0, 0],
      [0, 0, 0, 0]
    ];
  }


  getColorForValue(value) {
    const colors = {
      0: '#C1CDCD',
      1: '#00FFFF',
      2: '#FF6347',
      3: '#C0C0C0',
      6: '#C0C0C0',
      12: '#C0C0C0',
      24: '#C0C0C0',
      48: '#C0C0C0',
      96: '#C0C0C0',
      192: '#C0C0C0',
      384: '#C0C0C0',
      768: '#C0C0C0'
    };
    return colors[value] || '#F8F8FF';
  }

  displayInElement(elementId) { // HTML-Tabelle: Die Farben von Hintergrund (bgColor) und Text (textColor) passen sich dynamisch dem Wert der Kachel an.

    const container = document.getElementById(elementId);
    if (!container) return;
    
    let html = '<table>';
    
    for (let r = 0; r < 4; r++) {
      html += '<tr>';
      for (let c = 0; c < 4; c++) {
        const val = this.grid[r][c];
        const bgColor = this.getColorForValue(val);
        const textColor = val > 3 ? 'white' : '#776e65';
        
        html += `<td style="background-color: ${bgColor}; color: ${textColor};">`;
        html += val === 0 ? '' : val;
        html += '</td>';
      }
      html += '</tr>';
    }
    html += '</table>';
    
    container.innerHTML = html;
  }

}

// Spielfeld global machen für Button-Zugriff
let spielfeld;

function startGame() {
  spielfeld = new Spielfeld();
  spielfeld.displayInElement('board-display');
}

// Beim Laden starten
window.onload = startGame;